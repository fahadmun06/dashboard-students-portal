import './Charts.scss';
import React from 'react'

export default function Charts() {
    return (
        <div>Charts</div>
    )
}
