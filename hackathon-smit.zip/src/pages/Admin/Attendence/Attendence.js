import React from 'react'

export default function Attendence() {
  return (
    <div>Attendence</div>
  )
}
