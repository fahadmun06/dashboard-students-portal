import './Graphs.scss';
import React from 'react'

export default function Graphs() {
    return (
        <div>Graphs</div>
    )
}
