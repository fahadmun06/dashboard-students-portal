import './Sidebar.scss'
import React from 'react'
import { Link, Outlet } from 'react-router-dom';
import { Divider, Layout, Menu } from 'antd';
import Sider from 'antd/es/layout/Sider';
import { Content } from 'antd/es/layout/layout';


export default function SidebarMenu() {

    return (
        <>
            <main>
                <Layout className='bg-light layout'>
                    <Sider
                        breakpoint="lg"
                        collapsedWidth="0"
                        style={{
                            minWidth: '250px',
                            minHeight: "100vh",
                            marginRight: '10px',
                        }}
                    >
                        <div className="demo-logo-vertical" />
                        <span className={`text-light float-left fs-4 fw-bold m-3`}>SMIT Portal
                        </span>
                        <Menu
                            mode="inline"
                            theme='dark'
                            items={[
                                {
                                    key: '0',
                                    label: <Link to='/admin/charts' className='text-decoration-none fw-bold'>Charts</Link>
                                },
                                {
                                    key: '1',
                                    icon: <i className="fa-solid fa-forward-fast"></i>,
                                    label: <Link to='/admin/students-data' className='text-decoration-none'>Total Students</Link>
                                },
                                {
                                    key: '2',
                                    icon: <i className="fa-solid fa-list"></i>,
                                    label: <Link to='/admin/courses' className='text-decoration-none'>All Courses</Link>,
                                },
                                {
                                    key: '4',
                                    icon: <i className="fa-solid fa-note-sticky"></i>,
                                    label: <Link to='/admin/attendence' className='text-decoration-none'>Attendence</Link>,
                                },
                                {
                                    key: '5',
                                    icon: <i className="fa-solid fa-note-sticky"></i>,
                                    label: <Link to='/admin/graphs' className='text-decoration-none'>Graphs</Link>,
                                },
                            ]}
                        />
                        <Divider />
                        <Menu
                            mode='inline'
                            theme='dark'
                            items={[
                                {
                                    key: '1',
                                    icon: <i className="fa-solid fa-sliders"></i>,
                                    label: <Link className='text-decoration-none'>Setting</Link>,
                                },
                                {
                                    key: '2',
                                    icon: <i className="fa-solid fa-right-from-bracket text-danger"></i>,
                                    label: <Link className='text-decoration-none text-danger'>SignOut</Link>,
                                },
                            ]}
                        />
                    </Sider>
                    <Layout className={`bg-light`}>
                        <div>
                            <span className={`text-dark mt-2 fs-2 mb-0 fw-bold layout`} style={{ marginLeft: 30 }}>Welcome to Dashboard</span>
                        </div>
                        <Content className='content-home'
                            style={{
                                overflow: "auto",
                                backgroundColor: "white",
                                boxShadow: "rgba(0, 0, 0, 0.30) 0px 5px 15px"
                            }}
                        >
                            <Outlet />
                        </Content>
                    </Layout>
                </Layout>
            </main>
        </>
    )
}
