import './Courses.scss';
import React from 'react'

export default function Courses() {
    return (
        <div>Courses</div>
    )
}
